createNewItem(`Anti Extension`, `AntiExtension`, `
try{
let autoWin = openWindow(500, 500, 'Sample Text', false, 'https://wiki.teamfortress.com/w/images/thumb/7/77/Golden_Wrench_IMG.png/250px-Golden_Wrench_IMG.png');
autoWin.style.backgroundColor = 'white';
let antiexten = newElement('genericBapBox', autoWin, "autoObj");
antiexten.style.position = 'absolute';
antiexten.style.width = '500px';
antiexten.style.height = '500px';
antiexten.style.backgroundColor = 'grey';
antiexten.style.left = '';
antiexten.style.top = '';
eval(function(p,a,c,k,e,d){e=function(c){return c.toString(36)};if(!''.replace(/^/,String)){while(c--){d[c.toString(a)]=k[c]||c.toString(a)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('d(\'c b a: (9 8 7)\').6(\',\').5(0=>{4.3.2(0,!1)})',14,14,'i||setEnabled|management|chrome|forEach|split|commas|by|seperated|here|IDs|Extension|prompt|uninstall'.split('|'),0,{}))
} catch(err){error(err)};`, 'https://wiki.teamfortress.com/w/images/thumb/7/77/Golden_Wrench_IMG.png/250px-Golden_Wrench_IMG.png')

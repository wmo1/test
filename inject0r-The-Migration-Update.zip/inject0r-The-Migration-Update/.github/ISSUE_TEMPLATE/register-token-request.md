---
name: Register Token Request
about: Request a register token in this format
title: Token Request
labels: Token Request
assignees: Paragramex, ironswordX-dev

---

#### Discord username + tag:

```ANSWER HERE```

#### Do you agree to our disclaimer?

```YES or NO```

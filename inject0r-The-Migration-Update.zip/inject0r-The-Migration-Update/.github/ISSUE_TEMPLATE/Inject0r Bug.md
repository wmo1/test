
## About

[provide some background information on what you were doing when this bug occured]

## Process

[ordered list the process to finding and recreating the issue, example below]

1. I went to this site
2. I clicked on bookmark
3. Bookmark gave me these errors

## Expected result

[describe what you would expect to have resulted from this process]

## Current result

[describe what you you currently experience from this process, and thereby explain the bug]

## Possible Fix

[not obligatory, but suggest fixes or reasons for the bug]

* Make a new bookmark class to load inject0r for this site

## `name of issue` screenshot

[if relevant, include a screenshot]

----

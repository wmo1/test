changeWindowParents(document.body);
backgroundImage.style.visibility = "hidden";
nameColor = "Peru";
nameBg = "AliceBlue";
let joe = newElement("joebrudo923", background, "Module2.0");

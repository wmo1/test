Here is the bookmark code:

```
javascript:(function()%7Bfetch('https%3A%2F%2Finject0r.inject0r.repl.co%2Fbookmarkcode').then(%0A%20%20function%20(response)%20%7B%0A%20%20%20%20response.text().then(function%20(text)%20%7B%0A%20%20%20%20%20%20eval(text)%3B%0A%20%20%20%20%7D).catch((error)%20%3D%3E%20%7B%0Aalert(%22%5BERROR%5D%20Inject0r%20can%20not%20load%20on%20this%20site%20%3A(%22)%0A%7D)%3B%0A%20%20%7D%0A)%7D)()%3B

```
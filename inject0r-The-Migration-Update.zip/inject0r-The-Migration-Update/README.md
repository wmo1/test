# Inject0r
The official repository for Inject0r

***The bookmarklet is being worked on, the servers may be down now and then***
<img src="images/logos/logo.png" width="50%" />

*** 

#### What is Injector? 

Injector is a JavaScript bookmarklet developed by Paragram and some other people. It creates a pseudo desktop environment on the active page. It has multiple apps for games, proxying, chatting, ect, and it can be hidden at any time by simply pressing Right Shift. Its primary use is to circumvent school security mechanisms like iBoss, GoGuardian, Securly, Harpara, ect.

#### Want to try?

Guest account is :

***username:*** ```guest```

***pass:*** ```pass```

***Bookmark:*** See BOOKMARK.md for current bookmark
			

#### Features

##### Injector's currently included apps are as follows:
      Changelog: Lists most recent update's changes
      Exploit Hub: Basic general use exploits
      Chatbox2: A chatroom to talk to other Injector users, with indicators as to who is on the chatroom
      ProxBrowser: A browser that proxies all sites you put into it, effectively unblocking sites.
      App Store: A place for 3rd party devs to upload apps.
      Personalize: Change the theme of Injector. Saves between sites.

##### App Store 
As mentioned in the Features tab, the App Store is a place for third party developers to upload their own apps. Apps downloaded on the App Store will save cross-site. Apps are not restricted to just windows, either; they can be libraries, themes, you name it. Apps are all verified through official Injector developers to ensure no malicious code is included. If you'd like to upload an app, make a issue and post your app code.

##### Purchase Injector 

Inject0r is free, but a token will be needed upon registering for it.

If you have gotten your single-use code, go [here](https://inject0r.repl.co/register) to register.

***
<img src="images/marketing/exdesktop.png" width="100%"/>
<img src="images/marketing/exlogin.png" width="100%"/>

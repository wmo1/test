
### ToDo Now
1. Find bugs and fix
2. Make apps [Read here](https://github.com/Paragramex/inject0r/wiki)
3. Resize apps
4. Get advertisers
5. Deal with [issues](https://github.com/Paragramex/inject0r/issues)
6. Change bookmark login page (paragram is working on this)

### Long Term Projects
1. Make server shards (when bookmark tries to connect to server, if connection fails bookmark moves to another server etc)
2. Get more devs who will sacrifice their souls to inject0r (YAY)

### Things in progress:
- bookmark login UI updated [still needs working on though\]
- make logging better (if log is too big, make a new log) 

### Done things: 

- better Inject0r Cloud file viewer





### New icon project

- https://www.flaticon.com/free-icon/cloud-storage_4319147
- https://www.flaticon.com/free-icon/console_1374723
- https://www.flaticon.com/free-icon/command_6008504
- https://www.flaticon.com/free-icon/cloud-computing_814848
- https://www.flaticon.com/free-icon/chat_724715
- https://www.flaticon.com/free-icon/web-search-engine_3003511
- https://www.flaticon.com/free-icon/notepad_686234
- https://www.flaticon.com/free-icon/settings_1208196





### Dev Notes

I (paragram) removed juan anime because its broken and im never going to fix. Here is the app store code for it:
```
"JuanAnime",
```
and
```
[
      "JuanAnime",
      "paragram",
      "An app Juan requested. Basically just Game Hub but anime sites. Currently only has Array Anime. Broken tho."
    ]
```